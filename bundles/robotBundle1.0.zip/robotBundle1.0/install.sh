#!/usr/bin/env bash
set -euo pipefail

echo "[install.sh] Applying robot bundle..."

# Ensure scripts are executable
chmod +x scan_wifi.sh || true
chmod +x *.py || true

echo "[install.sh] Bundle install completed."
